package com.pcappstudio.launcher;

/** Pure-Java path policy, so the important edge cases can be tested without Android. */
public final class InstallerPath {
    private InstallerPath() {}

    public static boolean isInstaller(String name) {
        if (name == null) return false;
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        return lower.endsWith(".exe") || lower.endsWith(".msi");
    }

    public static String safeFileName(String raw) {
        if (raw == null) return "installer.exe";
        // Avoid Windows special names, separators, control chars and path traversal.
        String name = raw.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        while (name.startsWith(".")) name = name.substring(1);
        while (name.endsWith(".") || name.endsWith(" ")) name = name.substring(0, name.length() - 1);
        if (name.isEmpty()) name = "installer.exe";
        String base = name.contains(".") ? name.substring(0, name.lastIndexOf('.')) : name;
        if (base.matches("(?i)CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]")) name = "file_" + name;
        if (name.length() > 105) {
            int dot = name.lastIndexOf('.');
            String ext = dot > 0 ? name.substring(dot) : "";
            name = name.substring(0, Math.max(1, 105 - ext.length())) + ext;
        }
        return name;
    }

    public static String windowsPath(String storedName) {
        return "D:\\PCAppStudio\\" + storedName;
    }
}
