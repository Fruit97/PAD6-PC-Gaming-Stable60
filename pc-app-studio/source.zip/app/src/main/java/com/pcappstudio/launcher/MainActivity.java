package com.pcappstudio.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PC App Studio 0.2: a local file preparation and Winlator launcher.
 * Does NOT itself emulate Windows or silently install .exe files.
 */
public final class MainActivity extends Activity {
    private static final int PICK_PROGRAM = 1001;
    private static final int BG = Color.rgb(13, 16, 34);
    private static final int PANEL = Color.rgb(25, 31, 56);
    private static final int TEXT = Color.rgb(243, 245, 255);
    private static final int MUTED = Color.rgb(169, 177, 206);
    private static final int ACCENT = Color.rgb(142, 159, 255);
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<Entry> entries = new ArrayList<>();
    private LinearLayout listContainer;
    private TextView statusText;
    private ProgressBar busy;
    private Button importButton;
    private boolean copying;

    private static final class Entry {
        String displayName, storedName, mediaUri;
        long size;
        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("displayName", displayName);
            o.put("storedName", storedName);
            o.put("mediaUri", mediaUri);
            o.put("size", size);
            return o;
        }
        static Entry fromJson(JSONObject o) {
            Entry e = new Entry();
            e.displayName = o.optString("displayName", "");
            e.storedName = o.optString("storedName", "");
            e.mediaUri = o.optString("mediaUri", "");
            e.size = o.optLong("size", 0);
            return e;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        loadEntries();
        buildUi();
    }

    private int d(float dp) { return Math.round(dp * getResources().getDisplayMetrics().density); }
    private GradientDrawable background(int color, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(d(radius));
        return drawable;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(d(2), 1f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout vertical(int spacing) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(d(spacing), d(spacing), d(spacing), d(spacing));
        return l;
    }
    private LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = d(top);
        return p;
    }
    private Button button(String label, boolean primary, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.rgb(16, 20, 42) : TEXT);
        b.setBackground(background(primary ? ACCENT : Color.rgb(49, 57, 88), 14));
        b.setMinHeight(d(50));
        b.setOnClickListener(click);
        return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = vertical(18);
        root.setPadding(d(22), d(22), d(22), d(35));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("PC APP STUDIO", 13, ACCENT, true);
        brand.setLetterSpacing(.15f);
        root.addView(brand);
        root.addView(text("โปรแกรม PC บนแท็บเล็ต", 25, TEXT, true), lp(9));
        root.addView(text("เตรียมไฟล์ Windows บน Android แล้วเปิดผ่าน Winlator", 14, MUTED, false), lp(5));

        LinearLayout info = vertical(16);
        info.setBackground(background(PANEL, 22));
        root.addView(info, lp(21));
        info.addView(text("ติดตั้งโปรแกรม Windows", 18, TEXT, true));
        info.addView(text("รองรับไฟล์ติดตั้ง .EXE และ .MSI • จัดเก็บใน Download/PCAppStudio • ไม่ต้องรูท", 13, MUTED, false), lp(8));
        importButton = button("+ เลือกไฟล์ติดตั้ง PC", true, v -> chooseFiles());
        info.addView(importButton, lp(16));
        busy = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        busy.setIndeterminate(true);
        busy.setVisibility(View.GONE);
        info.addView(busy, lp(12));
        statusText = text("พร้อมนำเข้าไฟล์", 13, MUTED, false);
        info.addView(statusText, lp(10));

        LinearLayout engine = vertical(16);
        engine.setBackground(background(PANEL, 20));
        root.addView(engine, lp(16));
        engine.addView(text("ตัวรันโปรแกรม: Winlator", 18, TEXT, true));
        engine.addView(text("ใช้ Wine + Box64 ทำงานบนแท็บเล็ตเครื่องนี้ ไม่ใช่ Remote Desktop", 13, MUTED, false), lp(8));
        engine.addView(button("เปิด Winlator", false, v -> openWinlator()), lp(14));
        engine.addView(button("วิธีติดตั้งและเปิดไฟล์", false, v -> showGuide()), lp(7));

        root.addView(text("ไฟล์ติดตั้งที่นำเข้าแล้ว", 19, TEXT, true), lp(24));
        listContainer = vertical(0);
        listContainer.setPadding(0, 0, 0, 0);
        root.addView(listContainer, lp(10));
        root.addView(text("หมายเหตุ: เวอร์ชัน 0.2 ยังต้องเปิดตัวติดตั้งภายใน Winlator เอง ไม่สามารถสั่งติดตั้ง Windows อัตโนมัติจากแอปนี้ได้", 12, MUTED, false), lp(20));
        showEntries();
    }

    private void chooseFiles() {
        if (copying) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, PICK_PROGRAM);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_PROGRAM || result != RESULT_OK || data == null) return;
        List<Uri> selected = new ArrayList<>();
        ClipData multi = data.getClipData();
        if (multi != null) {
            for (int i = 0; i < multi.getItemCount(); i++) selected.add(multi.getItemAt(i).getUri());
        } else if (data.getData() != null) selected.add(data.getData());
        if (!selected.isEmpty()) importFiles(selected);
    }

    private String getName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null && !n.isEmpty()) return n;
            }
        } catch (Exception ignored) { }
        return uri.getLastPathSegment() != null ? uri.getLastPathSegment() : "installer.exe";
    }
    private long getSize(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) return Math.max(0, c.getLong(0));
        } catch (Exception ignored) { }
        return 0;
    }
    private void importFiles(List<Uri> uris) {
        copying = true;
        importButton.setEnabled(false);
        busy.setVisibility(View.VISIBLE);
        executor.execute(() -> {
            int success = 0, skipped = 0;
            for (Uri source : uris) {
                String name = InstallerPath.safeFileName(getName(source));
                if (!InstallerPath.isInstaller(name)) { skipped++; continue; }
                runOnUiThread(() -> statusText.setText("กำลังคัดลอก: " + name));
                Uri destination = null;
                try {
                    // MediaStore avoids MANAGE_EXTERNAL_STORAGE and supports large files via streaming.
                    ContentValues v = new ContentValues();
                    String unique = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS_", Locale.US).format(new Date()) + name;
                    v.put(MediaStore.Downloads.DISPLAY_NAME, unique);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
                    v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/PCAppStudio/");
                    v.put(MediaStore.Downloads.IS_PENDING, 1);
                    destination = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (destination == null) throw new IllegalStateException("สร้างไฟล์ปลายทางไม่ได้");
                    long copied = 0, lastUi = 0;
                    long size = getSize(source);
                    try (InputStream in = getContentResolver().openInputStream(source);
                         OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
                        if (in == null || out == null) throw new IllegalStateException("อ่านหรือเขียนไฟล์ไม่ได้");
                        byte[] buffer = new byte[256 * 1024];
                        int n;
                        while ((n = in.read(buffer)) != -1) {
                            out.write(buffer, 0, n);
                            copied += n;
                            long now = SystemClock.uptimeMillis();
                            if (now - lastUi > 600) {
                                long progress = copied;
                                runOnUiThread(() -> statusText.setText("กำลังคัดลอก " + name + " • " + formatSize(progress) + (size > 0 ? " / " + formatSize(size) : "")));
                                lastUi = now;
                            }
                        }
                        out.flush();
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(destination, done, null, null);
                    Entry e = new Entry();
                    e.displayName = name;
                    e.storedName = unique;
                    e.mediaUri = destination.toString();
                    e.size = copied;
                    runOnUiThread(() -> { entries.add(0, e); persist(); showEntries(); });
                    success++;
                } catch (Exception ex) {
                    if (destination != null) {
                        try { getContentResolver().delete(destination, null, null); } catch (Exception ignored) { }
                    }
                    String message = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                    runOnUiThread(() -> Toast.makeText(this, "นำเข้าไม่สำเร็จ: " + message, Toast.LENGTH_LONG).show());
                }
            }
            int count = success, invalid = skipped;
            runOnUiThread(() -> {
                copying = false;
                importButton.setEnabled(true);
                busy.setVisibility(View.GONE);
                statusText.setText("นำเข้าสำเร็จ " + count + " ไฟล์" + (invalid > 0 ? " • ข้ามไฟล์ที่ไม่ใช่ EXE/MSI " + invalid : ""));
                if (count > 0) showGuide();
            });
        });
    }

    private static String formatSize(long size) {
        if (size >= 1024L * 1024 * 1024) return String.format(Locale.US, "%.2f GB", size / (1024.0 * 1024 * 1024));
        if (size >= 1024L * 1024) return String.format(Locale.US, "%.1f MB", size / (1024.0 * 1024));
        return String.format(Locale.US, "%.1f KB", size / 1024.0);
    }
    private void showEntries() {
        if (listContainer == null) return;
        listContainer.removeAllViews();
        if (entries.isEmpty()) {
            TextView empty = text("ยังไม่มีไฟล์ • กดเลือกไฟล์ติดตั้ง PC ด้านบน", 14, MUTED, false);
            empty.setPadding(d(8), d(14), d(8), d(14));
            listContainer.addView(empty);
            return;
        }
        for (Entry e : new ArrayList<>(entries)) {
            LinearLayout card = vertical(14);
            card.setBackground(background(PANEL, 18));
            listContainer.addView(card, lp(10));
            card.addView(text("▣  " + e.displayName, 15, TEXT, true));
            card.addView(text(formatSize(e.size) + "  •  " + InstallerPath.windowsPath(e.storedName), 12, MUTED, false), lp(7));
            card.addView(button("คัดลอกพาธไฟล์ Windows", false, v -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("Winlator path", InstallerPath.windowsPath(e.storedName)));
                Toast.makeText(this, "คัดลอกพาธแล้ว", Toast.LENGTH_SHORT).show();
            }), lp(12));
            card.addView(button("เปิด Winlator เพื่อใช้งานไฟล์", true, v -> openWinlator()), lp(8));
            TextView remove = text("ลบไฟล์นี้", 13, MUTED, false);
            remove.setPadding(d(12), d(12), d(10), d(8));
            remove.setGravity(Gravity.RIGHT);
            remove.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("ลบไฟล์ติดตั้ง?")
                .setMessage("จะลบไฟล์ที่นำเข้าใน Download/PCAppStudio และนำออกจากรายการ")
                .setNegativeButton("ยกเลิก", null)
                .setPositiveButton("ลบ", (dialog, which) -> deleteEntry(e))
                .show());
            card.addView(remove);
        }
    }

    private void deleteEntry(Entry e) {
        executor.execute(() -> {
            try {
                getContentResolver().delete(Uri.parse(e.mediaUri), null, null);
                runOnUiThread(() -> { entries.remove(e); persist(); showEntries(); });
            } catch (Exception ex) {
                runOnUiThread(() -> Toast.makeText(this, "ลบไม่สำเร็จ: " + ex.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }
    private void loadEntries() {
        String data = getPreferences(MODE_PRIVATE).getString("entries", "[]");
        try {
            JSONArray a = new JSONArray(data);
            for (int i = 0; i < a.length(); i++) entries.add(Entry.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) { entries.clear(); }
    }
    private void persist() {
        JSONArray a = new JSONArray();
        try { for (Entry e : entries) a.put(e.toJson()); } catch (Exception ignored) { }
        getPreferences(MODE_PRIVATE).edit().putString("entries", a.toString()).apply();
    }
    private void openWinlator() {
        PackageManager pm = getPackageManager();
        String[] possible = {"com.winlator", "com.winlator.cmod", "com.winlator.bionic"};
        for (String pkg : possible) {
            Intent launch = pm.getLaunchIntentForPackage(pkg);
            if (launch != null) {
                try { startActivity(launch); return; } catch (Exception ignored) { }
            }
        }
        new AlertDialog.Builder(this)
            .setTitle("ยังไม่พบ Winlator")
            .setMessage("แอปนี้ต้องใช้ Winlator เป็นตัวรันโปรแกรม Windows ติดตั้งจาก GitHub ทางการ แล้วกลับมาเปิดอีกครั้ง")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("เปิดหน้า Winlator ทางการ", (dialog, which) -> {
                Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/brunodev85/winlator/releases"));
                startActivity(browser);
            }).show();
    }
    private void showGuide() {
        new AlertDialog.Builder(this)
            .setTitle("ติดตั้งโปรแกรม PC อย่างไร")
            .setMessage("1. เปิด Winlator แล้วสร้าง Container หนึ่งครั้ง\n\n2. เปิด Container และเข้า File Explorer\n\n3. เข้าไดรฟ์ D: แล้วเปิดโฟลเดอร์ PCAppStudio\n\n4. ดับเบิลคลิกไฟล์ .exe เพื่อติดตั้ง หรือเรียก msiexec /i กับไฟล์ .msi\n\n5. หลังติดตั้ง ให้เปิดโปรแกรมจาก Start Menu ภายใน Winlator\n\nข้อจำกัด: ตอนนี้แอปเราช่วยนำเข้าไฟล์และเปิด Winlator แต่ยังสั่งติดตั้งหรือเปิดโปรแกรม Windows โดยตรงไม่ได้ และไม่ได้รับประกันว่าทุกโปรแกรมจะทำงาน")
            .setPositiveButton("เข้าใจแล้ว", (dialog, which) -> { })
            .setNeutralButton("เปิด Winlator", (dialog, which) -> openWinlator())
            .show();
    }
    @Override protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
